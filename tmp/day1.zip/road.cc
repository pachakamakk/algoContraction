#include "road.h"

Road::Road(vector<pair<float,float>> points, bool oneWay, int speed)
{
  points = points;
  oneWay = oneWay;
  speed = speed;
}
