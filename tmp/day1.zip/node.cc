#include "node.h"

Node::Node(pair<float,float> &point, int id)
{
  point = point;
  id = id;
}
